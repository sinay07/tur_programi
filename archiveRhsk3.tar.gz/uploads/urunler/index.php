<?php
// Güvenlik - Klasör içeriğini gösterme
header("Location: ../../index.php");
exit;
?>


